import React, { useState, useEffect } from 'react';
import { 
  Building2, Factory, Trees, Car, Droplets, ArrowRight, CheckCircle2, 
  HelpCircle, AlertTriangle, Play, ChevronLeft, ChevronRight, RotateCcw,
  BarChart3, Layers, FileText, Check, ShieldAlert, Cpu
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceDot } from 'recharts';

const consumptionData = [
  { time: '0 h', hours: 0, rate: 120 },
  { time: '1 h', hours: 1, rate: 145 },
  { time: '2 h', hours: 2, rate: 160 },
  { time: '3 h', hours: 3, rate: 165 },
  { time: '4 h', hours: 4, rate: 160 },
  { time: '5 h', hours: 5, rate: 145 },
  { time: '6 h', hours: 6, rate: 120 },
];

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(1);
  const totalSlides = 15;

  const nextSlide = () => setCurrentSlide(prev => Math.min(prev + 1, totalSlides));
  const prevSlide = () => setCurrentSlide(prev => Math.max(prev - 1, 1));

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'ArrowRight' || e.key === 'Space') {
        nextSlide();
      } else if (e.key === 'ArrowLeft') {
        prevSlide();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="w-screen h-screen bg-slate-950 text-slate-100 flex flex-col justify-between overflow-hidden font-sans">
      
      {/* Top Header Navigation bar */}
      <header className="h-14 bg-slate-900/80 backdrop-blur border-b border-slate-800 px-6 flex items-center justify-between z-50">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-bold">
            <Droplets className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-semibold tracking-wide text-slate-200">El agua en una ciudad: Del consumo variable a la planificación inteligente</h1>
            <p className="text-xs text-slate-400">Cálculo Integral • Ingeniería Industrial • ABP Etapa 2</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <span className="text-xs px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-cyan-400 font-mono">
            Diapositiva {currentSlide} / {totalSlides}
          </span>
          <div className="flex items-center space-x-1">
            <button 
              onClick={prevSlide}
              disabled={currentSlide === 1}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-slate-200 transition"
              title="Anterior (Flecha Izquierda)"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button 
              onClick={nextSlide}
              disabled={currentSlide === totalSlides}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 text-slate-200 transition"
              title="Siguiente (Flecha Derecha / Espacio)"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Slide Presentation viewport (16:9 ratio style) */}
      <main className="flex-1 relative overflow-hidden flex items-center justify-center p-6 bg-slate-950">
        <div className="w-full max-w-[1700px] aspect-[16/9] max-h-[88vh] bg-slate-900 rounded-2xl border border-slate-800 shadow-2xl relative overflow-hidden flex flex-col animate-fade-in">
          
          {/* Slide 1: Portada */}
          {currentSlide === 1 && (
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-blue-950 flex flex-col justify-between p-16 relative overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(14,165,233,0.15),transparent_50%)]"></div>
              <div className="absolute top-12 right-12 text-cyan-400 opacity-20">
                <svg className="w-64 h-64" viewBox="0 0 200 200" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M100 20 C140 60, 160 100, 100 160 C40 100, 60 60, 100 20 Z" />
                  <path d="M50 100 Q100 50, 150 100" />
                </svg>
              </div>

              <div className="max-w-3xl z-10 my-auto">
                <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-medium mb-6 uppercase tracking-wider">
                  <span>Aprendizaje Basado en Problemas (ABP) — Etapa 2: Analizar</span>
                </div>
                <h2 className="text-6xl font-extrabold tracking-tight text-white mb-4 leading-tight">
                  EL <span className="text-cyan-400">AGUA</span> EN UNA CIUDAD
                </h2>
                <h3 className="text-2xl font-medium text-slate-300 mb-6">
                  Del consumo variable a la planificación inteligente
                </h3>
                <p className="text-slate-400 text-lg leading-relaxed max-w-2xl mb-8">
                  Aplicación del cálculo integral al análisis del consumo de agua en un complejo urbano sostenible.
                </p>
              </div>

              <div className="grid grid-cols-3 gap-6 pt-6 border-t border-slate-800/80 z-10 text-sm text-slate-400">
                <div>
                  <span className="text-slate-500 block text-xs uppercase font-semibold">Asignatura</span>
                  <span className="text-slate-200 font-medium">Cálculo Integral</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-xs uppercase font-semibold">Enfoque</span>
                  <span className="text-slate-200 font-medium">Ingeniería Civil y Ambiental</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-xs uppercase font-semibold">Institución</span>
                  <span className="text-slate-200 font-medium">Universidad de la Costa</span>
                </div>
              </div>
            </div>
          )}

          {/* Slide 2: El reto */}
          {currentSlide === 2 && (
            <div className="absolute inset-0 grid grid-cols-12 p-12 gap-12 items-center">
              <div className="col-span-7 flex flex-col justify-center space-y-6">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Contexto Urbano</span>
                <h2 className="text-4xl font-bold text-white leading-tight">El desafío de un complejo urbano</h2>
                <p className="text-slate-300 text-lg leading-relaxed">
                  El proyecto integra viviendas, zonas industriales, vías de acceso y áreas de conservación ambiental. Para garantizar su funcionamiento, es necesario estimar el consumo de recursos y dimensionar adecuadamente la infraestructura.
                </p>
                <div className="grid grid-cols-4 gap-4 pt-4">
                  <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4 text-center">
                    <Building2 className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                    <span className="text-xs text-slate-300 font-medium">Viviendas</span>
                  </div>
                  <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4 text-center">
                    <Factory className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                    <span className="text-xs text-slate-300 font-medium">Industria</span>
                  </div>
                  <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4 text-center">
                    <Car className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                    <span className="text-xs text-slate-300 font-medium">Vías</span>
                  </div>
                  <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4 text-center">
                    <Trees className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                    <span className="text-xs text-slate-300 font-medium">Conservación</span>
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-base font-semibold flex items-center space-x-3">
                  <Droplets className="w-6 h-6 shrink-0 text-cyan-400" />
                  <span>Nuestro reto: determinar cuánta agua consumen las viviendas durante seis horas cuando la demanda cambia con el tiempo.</span>
                </div>
              </div>

              <div className="col-span-5 h-full bg-slate-800/40 border border-slate-700 rounded-2xl p-6 flex flex-col justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/10 to-emerald-500/10"></div>
                <div className="relative z-10 space-y-4">
                  <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-700 pb-2 font-mono">
                    <span>RED DE ABASTECIMIENTO</span>
                    <span className="text-cyan-400">MAPA HIDRÁULICO</span>
                  </div>
                  <div className="h-64 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-center p-6 relative">
                    <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]"></div>
                    <div className="text-center space-y-3 z-10">
                      <div className="w-16 h-16 rounded-full bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center mx-auto text-cyan-400">
                        <Droplets className="w-8 h-8 animate-pulse" />
                      </div>
                      <p className="text-sm font-medium text-slate-200">Simulación de Flujo Dinámico en Tuberías</p>
                      <span className="text-xs text-cyan-400 block font-mono">q(t) = 120 + 30t - 5t²</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Slide 3: Pregunta concreta */}
          {currentSlide === 3 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Enfoque Analítico</span>
                <h2 className="text-3xl font-bold text-white">¿Qué necesitamos resolver?</h2>
              </div>

              <div className="grid grid-cols-3 gap-6 my-auto">
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="text-xs font-bold text-cyan-400 uppercase">Problema General</div>
                    <p className="text-slate-200 text-sm leading-relaxed">
                      ¿Cómo pueden las herramientas del cálculo integral apoyar la toma de decisiones en ingeniería y dimensionamiento de recursos?
                    </p>
                  </div>
                  <div className="mt-6 pt-4 border-t border-slate-700/60 flex items-center space-x-2 text-xs text-slate-400">
                    <HelpCircle className="w-4 h-4 text-cyan-400" />
                    <span>Contexto macro de diseño</span>
                  </div>
                </div>

                <div className="bg-cyan-950/40 border border-cyan-500/40 rounded-2xl p-6 flex flex-col justify-between relative shadow-lg shadow-cyan-950/50">
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 bg-cyan-500 text-slate-950 text-xs font-bold rounded-full uppercase">
                    Situación Seleccionada
                  </div>
                  <div className="space-y-3 mt-2">
                    <p className="text-cyan-200 text-base font-medium leading-relaxed text-center">
                      El consumo de agua de las viviendas varía de manera continua durante un periodo de seis horas.
                    </p>
                  </div>
                  <div className="mt-6 pt-4 border-t border-cyan-900/60 text-center text-xs text-cyan-400 font-mono">
                    Intervalo [0, 6] horas
                  </div>
                </div>

                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="text-xs font-bold text-emerald-400 uppercase">Pregunta Específica</div>
                    <p className="text-slate-200 text-sm leading-relaxed font-semibold">
                      ¿Cuál es el volumen total de agua consumido durante esas seis horas si la tasa de consumo cambia con el tiempo?
                    </p>
                  </div>
                  <div className="mt-6 pt-4 border-t border-slate-700/60 flex items-center space-x-2 text-xs text-slate-400">
                    <Droplets className="w-4 h-4 text-emerald-400" />
                    <span>Cálculo de volumen acumulado (L)</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-center space-x-8 text-xs text-slate-400 pt-4 border-t border-slate-800">
                <span className="flex items-center space-x-2"><span className="w-2 h-2 rounded-full bg-cyan-400"></span><span>Planificación de redes</span></span>
                <span className="flex items-center space-x-2"><span className="w-2 h-2 rounded-full bg-emerald-400"></span><span>Almacenamiento seguro</span></span>
                <span className="flex items-center space-x-2"><span className="w-2 h-2 rounded-full bg-blue-400"></span><span>Distribución eficiente</span></span>
              </div>
            </div>
          )}

          {/* Slide 4: ¿Por qué importa medir el consumo? */}
          {currentSlide === 4 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Utilidad Práctica</span>
                <h2 className="text-3xl font-bold text-white">Una decisión matemática con impacto real</h2>
              </div>

              <div className="grid grid-cols-2 gap-6 my-auto max-w-5xl mx-auto">
                <div className="bg-slate-800/60 border border-slate-700 p-6 rounded-2xl flex items-start space-x-4">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0 font-bold">1</div>
                  <div>
                    <h3 className="text-white font-semibold text-base mb-1">Demanda Variable</h3>
                    <p className="text-slate-300 text-sm leading-relaxed">El consumo depende estrictamente de la hora del día y de las actividades habituales de los habitantes del complejo.</p>
                  </div>
                </div>

                <div className="bg-slate-800/60 border border-slate-700 p-6 rounded-2xl flex items-start space-x-4">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0 font-bold">2</div>
                  <div>
                    <h3 className="text-white font-semibold text-base mb-1">Capacidad de Almacenamiento</h3>
                    <p className="text-slate-300 text-sm leading-relaxed">Conocer el volumen acumulado total ayuda a estimar de forma precisa la capacidad requerida en los tanques nodales.</p>
                  </div>
                </div>

                <div className="bg-slate-800/60 border border-slate-700 p-6 rounded-2xl flex items-start space-x-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0 font-bold">3</div>
                  <div>
                    <h3 className="text-white font-semibold text-base mb-1">Distribución Eficiente</h3>
                    <p className="text-slate-300 text-sm leading-relaxed">El cálculo integral contribuye a evaluar si la red de tuberías puede responder adecuadamente a los picos de demanda.</p>
                  </div>
                </div>

                <div className="bg-slate-800/60 border border-slate-700 p-6 rounded-2xl flex items-start space-x-4">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0 font-bold">4</div>
                  <div>
                    <h3 className="text-white font-semibold text-base mb-1">Riesgo de Estimación Deficiente</h3>
                    <p className="text-slate-300 text-sm leading-relaxed">Un modelo inadecuado puede conducir a un sobrecosto o a un dimensionamiento incorrecto de la infraestructura civil.</p>
                  </div>
                </div>
              </div>

              <div className="text-center text-xs text-slate-400">
                Objetivo central: Vincular el rigor del cálculo integral con la toma de decisiones en ingeniería urbana.
              </div>
            </div>
          )}

          {/* Slide 5: Las variables del modelo */}
          {currentSlide === 5 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="max-w-2xl space-y-2">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Definición Formal</span>
                <h2 className="text-3xl font-bold text-white">Las variables que describen el sistema</h2>
              </div>

              <div className="my-auto max-w-5xl mx-auto w-full">
                <div className="bg-slate-800/80 border border-slate-700 rounded-2xl overflow-hidden shadow-xl">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-900 text-cyan-400 text-xs font-mono uppercase tracking-wider border-b border-slate-700">
                        <th className="p-4 w-1/6">Símbolo</th>
                        <th className="p-4 w-1/4">Tipo de Variable</th>
                        <th className="p-4 w-1/4">Unidad</th>
                        <th className="p-4 w-1/3">Significado en el Sistema</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700/60 text-sm text-slate-300">
                      <tr className="hover:bg-slate-800/45 transition">
                        <td className="p-4 font-mono font-bold text-cyan-400 text-lg">t</td>
                        <td className="p-4">Independiente</td>
                        <td className="p-4 font-mono text-slate-400">Horas (h)</td>
                        <td className="p-4">Tiempo transcurrido desde el inicio del análisis</td>
                      </tr>
                      <tr className="hover:bg-slate-800/45 transition">
                        <td className="p-4 font-mono font-bold text-cyan-400 text-lg">q(t)</td>
                        <td className="p-4">Dependiente</td>
                        <td className="p-4 font-mono text-slate-400">Litros por hora (L/h)</td>
                        <td className="p-4">Tasa de consumo instantáneo de agua</td>
                      </tr>
                      <tr className="hover:bg-slate-800/45 transition">
                        <td className="p-4 font-mono font-bold text-emerald-400 text-lg">V</td>
                        <td className="p-4">Magnitud Acumulada</td>
                        <td className="p-4 font-mono text-slate-400">Litros (L)</td>
                        <td className="p-4">Volumen total consumido durante el intervalo</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center space-x-3 text-xs text-cyan-300">
                    <CheckCircle2 className="w-5 h-5 shrink-0 text-cyan-400" />
                    <span><strong>Información disponible:</strong> Función de consumo propuesta q(t) y periodo de análisis de 6 horas.</span>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center space-x-3 text-xs text-slate-400">
                    <HelpCircle className="w-5 h-5 shrink-0 text-slate-400" />
                    <span><strong>Información pendiente:</strong> Mediciones reales de campo y registros horarios detallados de los medidores.</span>
                  </div>
                </div>
              </div>

              <div className="text-center text-xs text-slate-500 font-mono">
                Precisión técnica: La tasa es flujo (L/h); el volumen es acumulación (L). No son magnitudes equivalentes.
              </div>
            </div>
          )}

          {/* Slide 6: El modelo matemático propuesto */}
          {currentSlide === 6 && (
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-blue-950 p-12 flex flex-col justify-between">
              <div className="max-w-2xl space-y-2">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Modelación Matemática</span>
                <h2 className="text-3xl font-bold text-white">Representar el consumo mediante una función</h2>
              </div>

              <div className="grid grid-cols-12 gap-8 my-auto items-center">
                <div className="col-span-7 space-y-6">
                  <p className="text-slate-300 text-base">La tasa de consumo de agua en el complejo urbano se modela formalmente mediante la función cuadrática:</p>
                  
                  <div className="p-6 rounded-2xl bg-slate-900/90 border border-cyan-500/40 text-center shadow-xl">
                    <span className="text-3xl lg:text-4xl font-mono font-bold text-cyan-300 tracking-wider">
                      q(t) = 120 + 30t - 5t²
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-slate-800/60 border border-slate-700/80 p-4 rounded-xl text-center">
                      <span className="text-xs text-slate-400 block uppercase font-mono">Tiempo (t)</span>
                      <span className="text-sm font-semibold text-slate-200">En horas</span>
                    </div>
                    <div className="bg-slate-800/60 border border-slate-700/80 p-4 rounded-xl text-center">
                      <span className="text-xs text-slate-400 block uppercase font-mono">Tasa q(t)</span>
                      <span className="text-sm font-semibold text-slate-200">Litros / hora</span>
                    </div>
                    <div className="bg-slate-800/60 border border-slate-700/80 p-4 rounded-xl text-center">
                      <span className="text-xs text-slate-400 block uppercase font-mono">Intervalo</span>
                      <span className="text-sm font-semibold text-slate-200">0 ≤ t ≤ 6</span>
                    </div>
                  </div>
                </div>

                <div className="col-span-5 bg-slate-900/60 border border-slate-700/80 p-6 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                    <span>COMPORTAMIENTO DEL MODELO</span>
                    <span className="text-cyan-400">PARÁBOLA DESCENDENTE</span>
                  </div>
                  <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={consumptionData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                        <XAxis dataKey="time" stroke="#94a3b8" fontSize={11} />
                        <YAxis stroke="#94a3b8" fontSize={11} domain={[100, 180]} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff' }} />
                        <Line type="monotone" dataKey="rate" stroke="#38bdf8" strokeWidth={3} dot={{ fill: '#38bdf8', r: 4 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-xs text-slate-400 text-center italic">
                    Nota: La tasa alcanza un máximo a las 3 horas (165 L/h) y luego disminuye gradualmente.
                  </p>
                </div>
              </div>

              <div className="text-xs text-slate-500 text-center font-mono">
                Función propuesta sujeta a calibración posterior con mediciones reales de campo.
              </div>
            </div>
          )}

          {/* Slide 7: ¿Qué significa integrar una tasa? */}
          {currentSlide === 7 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="max-w-2xl space-y-2">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Principio de Acumulación</span>
                <h2 className="text-3xl font-bold text-white">De una tasa instantánea a un volumen total</h2>
              </div>

              <div className="grid grid-cols-3 gap-6 my-auto items-center">
                <div className="bg-slate-800/60 border border-slate-700 p-6 rounded-2xl text-center space-y-4">
                  <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center mx-auto text-cyan-400">
                    <BarChart3 className="w-7 h-7" />
                  </div>
                  <h3 className="text-white font-semibold text-base">Tasa Variable q(t)</h3>
                  <p className="text-slate-300 text-sm leading-relaxed">Indica cuántos litros de agua se utilizan por hora en cada instante específico del tiempo.</p>
                  <span className="inline-block text-xs font-mono px-3 py-1 bg-cyan-500/10 text-cyan-400 rounded-full border border-cyan-500/30">Unidad: L / h</span>
                </div>

                <div className="bg-slate-800/60 border border-slate-700 p-6 rounded-2xl text-center space-y-4 shadow-xl border-cyan-500/30">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto text-emerald-400">
                    <Layers className="w-7 h-7" />
                  </div>
                  <h3 className="text-white font-semibold text-base">Integración en el Tiempo</h3>
                  <p className="text-slate-300 text-sm leading-relaxed">La integral definida acumula de manera continua la tasa de consumo a lo largo de todo el intervalo.</p>
                  <span className="inline-block text-xs font-mono px-3 py-1 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/30">Operación: ∫ q(t) dt</span>
                </div>

                <div className="bg-slate-800/60 border border-slate-700 p-6 rounded-2xl text-center space-y-4">
                  <div className="w-14 h-14 rounded-2xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center mx-auto text-blue-400">
                    <Droplets className="w-7 h-7" />
                  </div>
                  <h3 className="text-white font-semibold text-base">Volumen Acumulado V</h3>
                  <p className="text-slate-300 text-sm leading-relaxed">Permite obtener el total exacto consumido sin asumir que la tasa permanece constante.</p>
                  <span className="inline-block text-xs font-mono px-3 py-1 bg-blue-500/10 text-blue-400 rounded-full border border-blue-500/30">Unidad: Litros (L)</span>
                </div>
              </div>

              <div className="text-center text-xs text-slate-400 font-mono bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                Idea clave para recordar: Integrar una tasa respecto al tiempo siempre resulta en la cantidad total acumulada del recurso.
              </div>
            </div>
          )}

          {/* Slide 8: La integral definida */}
          {currentSlide === 8 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="max-w-2xl space-y-2">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Planteamiento Matemático</span>
                <h2 className="text-3xl font-bold text-white">El corazón del análisis: La integral definida</h2>
              </div>

              <div className="my-auto max-w-4xl mx-auto w-full text-center space-y-8">
                <p className="text-slate-300 text-base max-w-2xl mx-auto">
                  El volumen total consumido se obtiene integrando la función de tasa de consumo desde el tiempo inicial t = 0 hasta el tiempo final t = 6.
                </p>

                <div className="p-8 rounded-3xl bg-slate-900/90 border border-cyan-500/50 shadow-2xl inline-block px-16">
                  <div className="text-3xl lg:text-5xl font-mono font-bold text-cyan-300 tracking-wider">
                    V = <span className="text-cyan-400">∫</span>₀⁶ (120 + 30t - 5t²) dt
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-6 max-w-3xl mx-auto text-left">
                  <div className="bg-slate-800/60 border border-slate-700 p-4 rounded-xl">
                    <span className="text-xs text-cyan-400 font-mono block uppercase">Límite Inferior</span>
                    <span className="text-lg font-bold text-white">t = 0 h</span>
                    <p className="text-xs text-slate-400 mt-1">Inicio del turno de análisis hidráulico.</p>
                  </div>
                  <div className="bg-slate-800/60 border border-slate-700 p-4 rounded-xl">
                    <span className="text-xs text-emerald-400 font-mono block uppercase">Límite Superior</span>
                    <span className="text-lg font-bold text-white">t = 6 h</span>
                    <p className="text-xs text-slate-400 mt-1">Cierre del periodo continuo evaluado.</p>
                  </div>
                  <div className="bg-slate-800/60 border border-slate-700 p-4 rounded-xl">
                    <span className="text-xs text-blue-400 font-mono block uppercase">Resultado Esperado</span>
                    <span className="text-lg font-bold text-white">Volumen (L)</span>
                    <p className="text-xs text-slate-400 mt-1">Magnitud acumulada en litros.</p>
                  </div>
                </div>
              </div>

              <div className="text-center text-xs text-slate-500 font-mono">
                Planteamiento analítico formal para la estimación del tanque nodal.
              </div>
            </div>
          )}

          {/* Slide 9: El cálculo, desarrollado */}
          {currentSlide === 9 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="max-w-2xl space-y-1">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Resolución Analítica</span>
                <h2 className="text-2xl font-bold text-white">Desarrollo del cálculo paso a paso</h2>
              </div>

              <div className="my-auto max-w-4xl mx-auto w-full space-y-4">
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-sm font-mono">
                  <span className="text-cyan-400 font-bold">1. Función Inicial:</span>
                  <span className="text-slate-200">V = ∫₀⁶ (120 + 30t - 5t²) dt</span>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-sm font-mono">
                  <span className="text-cyan-400 font-bold">2. Antiderivada:</span>
                  <span className="text-slate-200">V = [ 120t + 15t² - (5/3)t³ ]₀⁶</span>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-sm font-mono">
                  <span className="text-cyan-400 font-bold">3. Evaluación en Límites:</span>
                  <span className="text-slate-200">V = [ 120(6) + 15(6)² - (5/3)(6)³ ] - [ 0 ]</span>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-sm font-mono">
                  <span className="text-cyan-400 font-bold">4. Operación Aritmética:</span>
                  <span className="text-slate-200">V = 720 + 540 - 360</span>
                </div>

                <div className="p-6 rounded-2xl bg-cyan-950/85 border border-cyan-500 text-center shadow-2xl">
                  <span className="text-xs text-cyan-300 font-mono uppercase block mb-1">Resultado Final Obtenido</span>
                  <span className="text-4xl font-mono font-extrabold text-cyan-300 tracking-wider">V = 900 L</span>
                </div>
              </div>

              <div className="text-center text-xs text-slate-500 font-mono">
                Verificación matemática: Antiderivada exacta con integración término a término.
              </div>
            </div>
          )}

          {/* Slide 10: ¿Cómo se interpreta el resultado? */}
          {currentSlide === 10 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Interpretación Física</span>
                <h2 className="text-3xl font-bold text-white">¿Qué nos dicen los 900 litros?</h2>
              </div>

              <div className="my-auto max-w-3xl mx-auto w-full text-center space-y-8">
                <div className="p-10 rounded-3xl bg-slate-900/90 border border-cyan-500/40 shadow-2xl relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-transparent to-emerald-500/10"></div>
                  <span className="text-xs text-cyan-400 font-mono uppercase tracking-widest block mb-2">Consumo Acumulado Estimado</span>
                  <h3 className="text-6xl font-black text-white font-mono tracking-tight mb-4">900 Litros</h3>
                  <div className="flex items-center justify-center space-x-6 text-xs text-slate-400 font-mono pt-4 border-t border-slate-800">
                    <span>Inicio: 0 h</span>
                    <span>•</span>
                    <span>Final: 6 h</span>
                    <span>•</span>
                    <span className="text-cyan-400">Estimación Teórica</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6 text-left">
                  <div className="bg-slate-800/60 border border-slate-700 p-6 rounded-2xl space-y-2">
                    <h4 className="text-white font-semibold text-sm flex items-center space-x-2">
                      <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                      <span>Utilidad en la Planificación</span>
                    </h4>
                    <p className="text-slate-300 text-xs leading-relaxed">
                      Sirve como referencia inicial indispensable para dimensionar la capacidad de almacenamiento de los tanques y evaluar la respuesta de la red hidráulica.
                    </p>
                  </div>
                  <div className="bg-slate-800/60 border border-slate-700 p-6 rounded-2xl space-y-2">
                    <h4 className="text-white font-semibold text-sm flex items-center space-x-2">
                      <ShieldAlert className="w-4 h-4 text-amber-400" />
                      <span>Alcance y Precaución</span>
                    </h4>
                    <p className="text-slate-300 text-xs leading-relaxed">
                      Es una estimación teórica derivada del modelo matemático propuesto, la cual debe ser contrastada y calibrada con datos reales de campo.
                    </p>
                  </div>
                </div>
              </div>

              <div className="text-center text-xs text-slate-500 font-mono">
                No debe interpretarse como caudal constante ni como medición comprobada.
              </div>
            </div>
          )}

          {/* Slide 11: Gráfica de la tasa de consumo */}
          {currentSlide === 11 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="max-w-2xl space-y-1">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Análisis Gráfico</span>
                <h2 className="text-3xl font-bold text-white">Comportamiento de la demanda en las 6 horas</h2>
              </div>

              <div className="grid grid-cols-12 gap-8 my-auto items-center max-w-6xl mx-auto w-full">
                <div className="col-span-8 bg-slate-900/80 border border-slate-700 p-6 rounded-2xl h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={consumptionData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="time" stroke="#94a3b8" fontSize={12} />
                      <YAxis stroke="#94a3b8" fontSize={12} domain={[100, 180]} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff' }} />
                      <Line type="monotone" dataKey="rate" stroke="#38bdf8" strokeWidth={3} dot={{ fill: '#38bdf8', r: 6 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="col-span-4 space-y-6">
                  <div className="p-6 rounded-2xl bg-cyan-950/60 border border-cyan-500/40 space-y-3">
                    <span className="text-xs text-cyan-400 font-mono uppercase block">Punto Máximo del Modelo</span>
                    <div className="text-3xl font-mono font-bold text-white">165 L/h</div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Ocurre exactamente a las <strong>t = 3 horas</strong> del turno de análisis.
                    </p>
                  </div>

                  <div className="bg-slate-800/60 border border-slate-700 p-6 rounded-2xl space-y-3">
                    <span className="text-xs text-slate-400 font-mono uppercase block">Dinámica del Flujo</span>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      La tasa aumenta progresivamente desde 120 L/h, alcanza su cúspide a mitad de jornada y desciende simétricamente hasta concluir el periodo.
                    </p>
                  </div>
                </div>
              </div>

              <div className="text-center text-xs text-slate-500 font-mono">
                Valores calculados analíticamente a partir de la función propuesta q(t).
              </div>
            </div>
          )}

          {/* Slide 12: Plan de solución */}
          {currentSlide === 12 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="max-w-2xl space-y-2">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Metodología de Trabajo</span>
                <h2 className="text-3xl font-bold text-white">Plan de solución: del modelo a la validación</h2>
              </div>

              <div className="grid grid-cols-2 gap-8 my-auto max-w-5xl mx-auto w-full">
                <div className="bg-slate-800/80 border border-slate-700 p-8 rounded-3xl space-y-6 relative">
                  <div className="absolute top-6 right-6 w-10 h-10 rounded-full bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-bold font-mono">
                    1
                  </div>
                  <div className="space-y-2">
                    <span className="text-xs text-cyan-400 font-mono uppercase">Etapa Inicial</span>
                    <h3 className="text-xl font-bold text-white">Definir Variables y Función</h3>
                  </div>
                  <div className="space-y-3 text-sm text-slate-300">
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-xs text-slate-400 block font-mono">PRODUCTO ESPERADO</span>
                      <span>Modelo matemático de la tasa de consumo q(t).</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-xs text-slate-400 block font-mono">CRITERIO DE VALIDACIÓN</span>
                      <span>Unidades coherentes y tasa positiva en todo el intervalo.</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-800/80 border border-slate-700 p-8 rounded-3xl space-y-6 relative">
                  <div className="absolute top-6 right-6 w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-bold font-mono">
                    2
                  </div>
                  <div className="space-y-2">
                    <span className="text-xs text-emerald-400 font-mono uppercase">Etapa de Análisis</span>
                    <h3 className="text-xl font-bold text-white">Calcular y Validar el Volumen</h3>
                  </div>
                  <div className="space-y-3 text-sm text-slate-300">
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-xs text-slate-400 block font-mono">PRODUCTO ESPERADO</span>
                      <span>Consumo acumulado (900 L) y análisis de sensibilidad.</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-xs text-slate-400 block font-mono">CRITERIO DE VALIDACIÓN</span>
                      <span>Resultado expresado en litros y contraste con medidores.</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-center text-xs text-slate-400 font-mono bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                La solución analítica no concluye con el cálculo numérico; requiere comprobar rigurosamente su coherencia física.
              </div>
            </div>
          )}

          {/* Slide 13: Supuestos, limitaciones y datos pendientes */}
          {currentSlide === 13 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="max-w-2xl space-y-1">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Validación de Hipótesis</span>
                <h2 className="text-3xl font-bold text-white">Supuestos, limitaciones y datos pendientes</h2>
              </div>

              <div className="grid grid-cols-2 gap-6 my-auto max-w-5xl mx-auto w-full">
                <div className="bg-emerald-950/30 border border-emerald-500/30 p-6 rounded-2xl space-y-4">
                  <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-base">
                    <CheckCircle2 className="w-5 h-5" />
                    <span>Supuestos del Modelo</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-300 list-disc list-inside">
                    <li>La función aproxima adecuadamente la tasa real de consumo.</li>
                    <li>El periodo corresponde estrictamente a seis horas continuas.</li>
                    <li>No existen fugas ni pérdidas catastróficas en la red.</li>
                    <li>Las unidades de medida se mantienen consistentes (L y h).</li>
                  </ul>
                </div>

                <div className="bg-amber-950/30 border border-amber-500/30 p-6 rounded-2xl space-y-4">
                  <div className="flex items-center space-x-2 text-amber-400 font-semibold text-base">
                    <AlertTriangle className="w-5 h-5" />
                    <span>Limitaciones y Restricciones</span>
                  </div>
                  <ul className="space-y-2 text-xs text-slate-300 list-disc list-inside">
                    <li>Posibles fluctuaciones en el número de habitantes activos.</li>
                    <li>Variaciones imprevistas en la presión de suministro.</li>
                    <li>Hábitos de consumo atípicos no contemplados en la función.</li>
                    <li>Modelo simplificado sin calibración previa en terreno.</li>
                  </ul>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-center text-xs text-cyan-400 font-mono">
                Ciclo de mejora: <strong>Medir → Comparar → Ajustar → Validar</strong> con registros de medidores reales.
              </div>
            </div>
          )}

          {/* Slide 14: Conclusiones */}
          {currentSlide === 14 && (
            <div className="absolute inset-0 p-12 flex flex-col justify-between">
              <div className="max-w-2xl space-y-1">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Síntesis del Proyecto</span>
                <h2 className="text-3xl font-bold text-white">Conclusiones: de las matemáticas a la ingeniería</h2>
              </div>

              <div className="my-auto max-w-5xl mx-auto w-full grid grid-cols-5 gap-4">
                <div className="bg-slate-800/70 border border-slate-700 p-5 rounded-2xl flex flex-col justify-between">
                  <span className="text-xs font-mono text-cyan-400 font-bold">01</span>
                  <div className="space-y-1 my-3">
                    <h3 className="text-white font-semibold text-sm">Consumo Variable</h3>
                    <p className="text-slate-300 text-xs leading-relaxed">Representable mediante una función dependiente del tiempo.</p>
                  </div>
                </div>

                <div className="bg-slate-800/70 border border-slate-700 p-5 rounded-2xl flex flex-col justify-between">
                  <span className="text-xs font-mono text-cyan-400 font-bold">02</span>
                  <div className="space-y-1 my-3">
                    <h3 className="text-white font-semibold text-sm">Integral Definida</h3>
                    <p className="text-slate-300 text-xs leading-relaxed">Transforma flujo instantáneo (L/h) en volumen total (L).</p>
                  </div>
                </div>

                <div className="bg-cyan-950/80 border border-cyan-500/50 p-5 rounded-2xl flex flex-col justify-between shadow-xl">
                  <span className="text-xs font-mono text-cyan-300 font-bold">03</span>
                  <div className="space-y-1 my-3">
                    <h3 className="text-cyan-200 font-semibold text-sm">Estimación 900 L</h3>
                    <p className="text-cyan-300/80 text-xs leading-relaxed">Volumen acumulado teórico durante las 6 horas analizadas.</p>
                  </div>
                </div>

                <div className="bg-slate-800/70 border border-slate-700 p-5 rounded-2xl flex flex-col justify-between">
                  <span className="text-xs font-mono text-emerald-400 font-bold">04</span>
                  <div className="space-y-1 my-3">
                    <h3 className="text-white font-semibold text-sm">Decisión Técnica</h3>
                    <p className="text-slate-300 text-xs leading-relaxed">Apoya la planificación de tanques y redes de abastecimiento.</p>
                  </div>
                </div>

                <div className="bg-slate-800/70 border border-slate-700 p-5 rounded-2xl flex flex-col justify-between">
                  <span className="text-xs font-mono text-emerald-400 font-bold">05</span>
                  <div className="space-y-1 my-3">
                    <h3 className="text-white font-semibold text-sm">Validación Real</h3>
                    <p className="text-slate-300 text-xs leading-relaxed">Los datos de campo permitirán evaluar y ajustar el modelo.</p>
                  </div>
                </div>
              </div>

              <div className="text-center text-xs text-cyan-400 font-mono bg-cyan-950/30 p-3 rounded-xl border border-cyan-500/20">
                «Medir el consumo es el primer paso indispensable para diseñar una infraestructura urbana eficiente.»
              </div>
            </div>
          )}

          {/* Slide 15: Evidencias y cierre */}
          {currentSlide === 15 && (
            <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-950 to-blue-950 p-12 flex flex-col justify-between">
              <div className="max-w-2xl space-y-1">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-widest">Cierre de Presentación</span>
                <h2 className="text-3xl font-bold text-white">De la estimación a una solución verificable</h2>
              </div>

              <div className="grid grid-cols-12 gap-8 my-auto items-center max-w-5xl mx-auto w-full">
                <div className="col-span-7 space-y-4">
                  <p className="text-slate-300 text-sm font-medium">Para completar el proceso colaborativo, el entregable incluye:</p>
                  <div className="space-y-2 text-sm text-slate-300">
                    <div className="flex items-center space-x-3 p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <Check className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>Distribución formal de roles en el equipo de ingeniería.</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <Check className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>Bitácora de reuniones y avances del modelo matemático.</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <Check className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span>Fuentes bibliográficas y normativas técnicas consultadas.</span>
                    </div>
                  </div>
                </div>

                <div className="col-span-5 bg-cyan-950/50 border border-cyan-500/40 p-6 rounded-3xl text-center space-y-4 shadow-2xl">
                  <div className="w-16 h-16 rounded-full bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center mx-auto text-cyan-400">
                    <Droplets className="w-8 h-8 animate-bounce" />
                  </div>
                  <h3 className="text-white font-bold text-lg">¿Preguntas o comentarios?</h3>
                  <p className="text-xs text-cyan-300 leading-relaxed">
                    ¿Cómo podemos mejorar la precisión del modelo con mediciones reales de consumo en campo?
                  </p>
                </div>
              </div>

              <div className="text-center text-xs text-slate-500 font-mono">
                Universidad de la Costa • Facultad de Ingeniería • Cálculo Integral 2026
              </div>
            </div>
          )}

        </div>
      </main>

      {/* Footer Navigation Bar */}
      <footer className="h-14 bg-slate-900/80 backdrop-blur border-t border-slate-800 px-6 flex items-center justify-between z-50 text-xs">
        <div className="text-slate-400 flex items-center space-x-2">
          <span>Usa las flechas</span>
          <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono">←</kbd>
          <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 rounded text-slate-300 font-mono">→</kbd>
          <span>para navegar entre diapositivas</span>
        </div>

        <div className="flex items-center space-x-2">
          {Array.from({ length: totalSlides }).map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx + 1)}
              className={`h-2 rounded-full transition-all ${
                currentSlide === idx + 1 ? 'w-6 bg-cyan-400' : 'w-2 bg-slate-700 hover:bg-slate-600'
              }`}
              title={`Ir a diapositiva ${idx + 1}`}
            />
          ))}
        </div>

        <div className="text-slate-400 font-mono">
          ABP • Etapa 2
        </div>
      </footer>

    </div>
  );
}
